from django.contrib import admin
from .models import Student, Employer

# Register your models here.
admin.site.register(Student)
admin.site.register(Employer)
